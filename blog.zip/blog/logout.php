<?php
//session_unset();
session_start();
//session_unset();
if (isset($_SESSION['user'])) {
    unset($_SESSION['user']);
    print_r($_SESSION);
}
print_r($_SESSION);
?>
<h1>Logged out</h1>
<a href="index.php">Click to continue</a>
