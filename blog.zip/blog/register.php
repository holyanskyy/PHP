<?php
session_start();
require_once 'db.php';

function getForm($nm='',$em=''){    
 return <<< JAMISSWEET
<div style="width: 800px; margin: 0 auto;">
    <h2 style="text-align:center">Add new user</h2> 
    <div style="width: 400px; margin: 0 auto; border: 1px solid black; padding:20px;">
    <form method="post">
        <p style="width:120px; display:inline-block;">Name: </p><input type="text" name="name" value="$nm"><br>
        <p style="width:120px; display:inline-block;">Emai: </p><input type="text" name="email" value="$em"><br>
        <p style="width:120px; display:inline-block;">Password: </p><input type="text" name="pass"><br>
        <p style="width:120px; display:inline-block;">Repeat password: </p><input type="text" name="passRepeat"><br><br>
        <input type="submit" value="REGISTER">
    </form>
    </div>
</div>
JAMISSWEET;
}

if (!isset($_POST['name'])) {
    // STATE 1: First show
    echo getForm();
} else {    
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['pass']; 
    $passRepeat = $_POST['passRepeat'];
    // submission received - verify
    $errorList = array();     
    if (strlen($name) < 4) {
        array_push($errorList, "Name must be at least 4 characters long");
    }    
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
        array_push($errorList, "Email maust like aaa@aaa.a");
    } else {
        $sql = sprintf("SELECT ID FROM users WHERE email='%s'", mysqli_escape_string($conn, $email));
        $result = mysqli_query($conn, $sql);
        if (!$result) {
            die("Error executing query [ $sql ] : " . mysqli_error($conn));
        }
        if (mysqli_num_rows($result) != 0) {
            array_push($errorList, "Email already registered");
        }
    }
    if ($pass !== $passRepeat) {
        array_push($errorList, "Password must be equal");
    }
    if (strlen($pass) <= '8') {
        array_push($errorList, "Password Must Contain At Least 8 Characters!");
    }
     /*if(!preg_match("/[0-9]+/",$password)) {
        array_push($errorList, "Your Password Must Contain At Least 1 Number!");
    }
    if(!preg_match("/[A-Z]+/",$password)) {
        array_push($errorList, "Your Password Must Contain At Least 1 Capital Letter!");
    }
    if(!preg_match("/[a-z]+/",$password)) {
        array_push($errorList, "Your Password Must Contain At Least 1 Lowercase Letter!");
    }  
   if(!preg_match("/!@#$%^&*$+/",$password)) {
        array_push($errorList, "Your Password Must Contain At Least 1 Lowercase Letter!");
    }  */
    /*if (!preg_match('/[0-9;\'".,<>`~|!@#$%^&*()_+=-]/', $pass1) || (!preg_match('/[a-z]/', $pass1)) || (!preg_match('/[A-Z]/', $pass1)) || (strlen($pass1) < 8)) {
        array_push($errorList, "Password must be at least 8 characters " .
                "long, contain at least one upper case, one lower case, " .
                " one digit or special character");
    } else if ($pass1 != $pass2) {
        array_push($errorList, "Passwords don't match");
    }*/
    if ($errorList) {
        // STATE 3: submission failed - problems found
        echo "<h5>Problems found in your submission</h5>\n";
        echo "<ul>\n";
        foreach ($errorList as $error) {
            echo "<li>" . htmlspecialchars($error) . "</li>";
        }
        echo "</ul>\n";
        echo getForm($name, $email);
    } else {
        // STATE 2: submission successful
        $sql = sprintf("INSERT INTO users VALUES (NULL, '%s', '%s', '%s')", mysqli_escape_string($conn, $name), mysqli_escape_string($conn, $email), mysqli_escape_string($conn, $pass));
        $result = mysqli_query($conn, $sql);
        if (!$result) {
            die("Error executing query [ $sql ] : " . mysqli_error($conn));
        }
        echo "<h1>Registration successful</h1>\n";
        echo '<a href="login.php">Click to login</a>';        
    }
}

