<?php

    $db_user="blog";
    $db_name="blog";
    $db_pass="fr2A8mSVB39qaQ8K";

    $conn = mysqli_connect('localhost',$db_user,$db_pass, $db_name);
    if (!$conn)
    {       
        die("Error connection to DB".mysqli_error($conn));
    }

