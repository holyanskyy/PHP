<?php
session_start(); 
require_once 'db.php';

function getLoginForm() {
    return <<< ENDTAG
<div style="width: 800px; margin: 0 auto;">
    <h2 style="text-align:center">Login</h2>
    <div style="width: 400px; margin: 0 auto; border: 1px solid black; padding:20px;">    
    <form method="post">
        <p style="width:120px; display:inline-block;">Email: </p><input type="text" name="email"><br>
        <p style="width:120px; display:inline-block;">Password: </p><input type="password" name="pass"><br><br>
        <input type="submit" value="Login"><br>
        <p style="text-align:right;"><a href="register.php">No account? Register here. </a></p>
    </form>
    </div>
</div>
ENDTAG;
}
/* Create login for with email,password,submit inputs.
 * Verify user login with database, fetch record by email alone.
 * Verify password in PHP (!), not in SQL query.
 */
if (!isset($_POST['email'])) {
    echo getLoginForm();
} else {
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $sql = sprintf("SELECT * FROM users WHERE email='%s'", mysqli_escape_string($conn, $email));
    $result = mysqli_query($conn, $sql);
    if (!$result) {
        die("Error executing query [ $sql ] : " . mysqli_error($conn));
    }
    if (mysqli_num_rows($result) == 0) {
        echo "<p>Login failed</p>";
        echo getLoginForm();        
    } else {
        $row = mysqli_fetch_assoc($result);
        // password MUST be compared in PHP because SQL is case-insenstive
        if ($row['password'] == $pass) {
            // LOGIN successful
            unset($row['password']);
            $_SESSION['user'] = $row;//['name'];
            //$_SESSION['userID'] = $row['ID'];
            echo "<h1>Login successful.</h1>";
            echo '<a href="index.php">Click to continue</a>';
        } else {
            echo "<p>Login failed</p>";
            echo getLoginForm();
        }
    }
}

