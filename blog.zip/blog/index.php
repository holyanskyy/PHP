<?php session_start(); ?>
<!DOCTYPE html> 
<html>
    <head>
        <meta charset="UTF-8">
        <title>BLOG</title>
    </head>
    <body>
        <div style="width: 800px; margin: 0 auto;">
        <?php
        require_once 'db.php';
        //echo "<pre>\nSESSION:\n";
        //print_r($_SESSION);
        //echo "</pre>\n\n";
        if (isset($_SESSION['user'])) {
            echo '<p style="text-align:right;">';
            echo "You are loged as " . $_SESSION['user']['name'] . ". ";
            echo '<a href="logout.php"> Logout</a> <br/>' .
             '<a href="articladdedit.php">Post an article</a>.</p>';
            $currentUserId=$_SESSION['user']['ID'];
        } else {
            echo '<p style="text-align:right;">';
            echo "You are not logged in. <br/>";
            echo '<a href="login.php">Login</a> or <a href="register.php">Register</a> to post article and comments.</p>';
            $currentUserId="";
        }
        
        $sql = "SELECT * FROM articles ORDER BY id DESC LIMIT 5";
        $result= mysqli_query($conn,$sql);
                    if (!$result){                
                        die("Error executing query [$sql] : ".mysql_error($conn));
                    }            
        $numrows= mysqli_num_rows($result);
        $dataRows = mysqli_fetch_all($result,MYSQLI_ASSOC);
        echo '<h2 style="text-align:center;">Welcome to my blog, read on!</h2><br/>';
        echo "<ul>\n";
        foreach($dataRows as $row){
            $ID=$row['ID'];
            $title= htmlspecialchars($row['title']);
            $author= htmlspecialchars($row['authorID']);
            $body=htmlspecialchars($row['body']);
            $datePub=$row['pubDate']; 
            echo "<li><h3><a href=\"articleview.php?id=$ID\"".' style="text-decoration: none;">' . $title .'</a></h3><p style="font-style:italic;font-size:90%;"> Posted by '.$author." on ".$datePub."</p><p>".iconv_substr($body,0,200)."...</p></li>";            
            
            if ($author==$currentUserId){
                echo "<a href=\"articladdedit.php?id=$ID\"style=\"text-decoration: none;\">Edit article</a>";
            }
            echo "<br/><hr/>";
        }
        echo "</ul>\n";
        ?>
            </div>
    </body>
</html>
