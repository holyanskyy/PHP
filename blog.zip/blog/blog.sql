-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 26, 2016 at 03:17 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `authorID` int(11) NOT NULL,
  `pubDate` date NOT NULL,
  `title` varchar(200) NOT NULL,
  `body` text NOT NULL,
  `imagePath` varchar(250) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `authorID` (`authorID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`ID`, `authorID`, `pubDate`, `title`, `body`, `imagePath`) VALUES
(1, 2, '2016-09-01', 'First article', 'aaaaaaaaaaaaa sssssssssssss dddddddd fffffffffffffff ggggggggg ', ''),
(8, 4, '2016-09-23', 'aaaaaaaaaa a aaaaaaaaaaa', 'aaaaaaaaaaaa aaaaaaaaaaaa a aaaaaaaaa aaaaaaaa aaaaaaaaaaaaaa aaaaaaaaaaaa aaaaaaaaaaaaa aaaaaaaaaaaaa aaaaaaaaaa aaaaaaaaaaaa aaaaaaaaa aaaaaaaaaaaaa', ''),
(9, 4, '2016-09-23', 'aaaaaaaaaa a aaaaaaaaaaa', 'aaaaaaaaaaaa aaaaaaaaaaaa a aaaaaaaaa aaaaaaaa aaaaaaaaaaaaaa aaaaaaaaaaaa aaaaaaaaaaaaa aaaaaaaaaaaaa aaaaaaaaaa aaaaaaaaaaaa aaaaaaaaa aaaaaaaaaaaaa', ''),
(10, 4, '2016-09-23', 'Xxxxxxxxxxxxxxxxx', 'xxxxxxxxxxxx xxxxxxxxxxxxx xxxxxxxxxxxx xxxxxxxxxxxx xxxxxxxxxxx xxxxxxxxxxxx xxxxxxxxxx xxxxxxxxxx xxxxxxxxxxxxx xxxxxxxxxxxx xxxxxxxxxx', ''),
(11, 4, '2016-09-23', 'Yyyyyyyyyy y x', 'xxxxxxxxxxxx xxxxxxxxxxxxx xxxxxxxxxxxx xxxxxxxxxxxx xxxxxxxxxxx xxxxxxxxxxxx xxxxxxxxxx xxxxxxxxxx xxxxxxxxxxxxx xxxxxxxxxxxx xxxxxxxxxx', ''),
(12, 4, '2016-09-23', 'Yyyyyyyyyy y x', 'xxxxxxxxxxxx xxxxxxxxxxxxx xxxxxxxxxxxx xxxxxxxxxxxx xxxxxxxxxxx xxxxxxxxxxxx xxxxxxxxxx xxxxxxxxxx xxxxxxxxxxxxx xxxxxxxxxxxx xxxxxxxxxx', ''),
(13, 2, '2016-09-25', 'aaaaaaaaa', 'bbbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbbbbbbbb  bbbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbb', 'uploads/20160925-140948-DSCN3419_JPG.jpeg'),
(14, 4, '2016-09-25', 'kuku', 'bbbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbbbbbbbb  bbbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbb', 'uploads/20160925-155433-1_JPG.jpeg'),
(15, 3, '2016-09-25', 'kuku kuku', 'bbbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbbbbbbbb  bbbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbb', 'uploads/20160925-155501-1_JPG.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `articleID` int(11) NOT NULL,
  `authorID` int(11) NOT NULL,
  `body` varchar(1000) NOT NULL,
  `pubTimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `articleID` (`articleID`),
  KEY `authorID` (`authorID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`ID`, `articleID`, `authorID`, `body`, `pubTimestamp`) VALUES
(1, 15, 1, 'kuku kukuku', '2016-09-25 22:50:16'),
(2, 15, 2, 'bla bla bla bla', '2016-09-25 22:50:50'),
(6, 15, 3, 'tralalalala', '2016-09-26 01:12:24');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `name`, `email`, `password`) VALUES
(1, 'lery', 'lery@hotmail.com', 'Privet1'),
(2, 'valeriy', 'aaa@mail.com', 'a12345678'),
(3, 'pupkin', 'pupkin@mail.com', 'A12345678'),
(4, 'petrov', 'ppp@mail.ru', 'p12345678');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `articles_ibfk_1` FOREIGN KEY (`authorID`) REFERENCES `users` (`ID`);

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`articleID`) REFERENCES `articles` (`ID`),
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`authorID`) REFERENCES `users` (`ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
