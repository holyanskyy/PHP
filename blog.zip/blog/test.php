<?php

$name = "my1_picture.png";
echo " Name befor changing: ".$name;
$name = preg_replace('/[^A-Za-z0-9\-]/', '_', $name);
echo "<br/><br/> Name after changing: ".$name;

$elements = array('a', 'b', 'c');

echo "<ul><li>" . implode("</li><li>", $elements) . "</li></ul>";